package com.dumbity.mod;

import com.mality.mod.Family;
import com.mality.mod.MalityBoxItem;
import com.mality.mod.MalityEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Dumbity modu: Mality'nin sevgilisi. Mality Mod (malitymod) gerektirir. */
@Mod(DumbityMod.MODID)
public class DumbityMod {
    public static final String MODID = "dumbitymod";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final RegistryObject<EntityType<DumbityEntity>> DUMBITY = ENTITIES.register("dumbity",
            () -> EntityType.Builder.of(DumbityEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 0.9F)
                    .clientTrackingRange(10)
                    .build("dumbity"));

    public static final RegistryObject<Item> DUMBITY_BOX_ITEM = ITEMS.register("dumbity_box",
            () -> new MalityBoxItem("dumbity"));

    public static final RegistryObject<Item> DUMBITY_SPAWN_EGG = ITEMS.register("dumbity_spawn_egg",
            () -> new ForgeSpawnEggItem(DUMBITY, 0xFF8FB8, 0x7A3B5E, new Item.Properties()));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.dumbitymod.main"))
                    .icon(() -> new ItemStack(DUMBITY_BOX_ITEM.get()))
                    .displayItems((params, output) -> {
                        output.accept(DUMBITY_BOX_ITEM.get());
                        output.accept(DUMBITY_SPAWN_EGG.get());
                    })
                    .build());

    public DumbityMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
        bus.addListener(this::onAttributes);
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(() ->
                Family.register(new Family.Member("dumbity", DUMBITY::get,
                        new ResourceLocation(MODID, "textures/entity/dumbity_box.png")))));

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, DumbityConfig.SPEC);
        MinecraftForge.EVENT_BUS.register(new DumbityEvents());
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        event.put(DUMBITY.get(), MalityEntity.createAttributes().build());
    }
}
