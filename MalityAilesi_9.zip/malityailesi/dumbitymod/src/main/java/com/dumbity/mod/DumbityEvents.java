package com.dumbity.mod;

import com.mality.mod.FishClient;
import com.mality.mod.MalityEvents;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class DumbityEvents {
    /** Dünyaya ilk girişte pembe kutu (Dumbity) yanında doğar. */
    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (sp.getPersistentData().getBoolean("dumbityBoxGiven")) return;
        sp.getPersistentData().putBoolean("dumbityBoxGiven", true);
        sp.getServer().execute(() -> spawnBox(sp));
    }

    private static void spawnBox(ServerPlayer sp) {
        ServerLevel l = sp.serverLevel();
        Direction d = sp.getDirection();
        BlockPos front = sp.blockPosition().relative(d, 3);
        MalityEvents.spawnBox(l, front.relative(d.getClockWise(), 2), "dumbity", d);
    }

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent event) {
        /** /dumbitykutu : pembe kutuyu yine yanında doğurur. */
        event.getDispatcher().register(Commands.literal("dumbitykutu").executes(ctx -> {
            spawnBox(ctx.getSource().getPlayerOrException());
            return 1;
        }));
        /** /dumbityses <id> : Dumbity'nin Fish Audio ses modelini ayarlar (link de olur). */
        event.getDispatcher().register(Commands.literal("dumbityses")
                .then(Commands.argument("id", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            String id = FishClient.cleanVoiceId(StringArgumentType.getString(ctx, "id"));
                            DumbityConfig.VOICE.set(id);
                            DumbityConfig.VOICE.save();
                            ctx.getSource().sendSuccess(() -> Component.literal("\u00A7bDumbity'nin ses modeli: " + id), false);
                            return 1;
                        })));
    }
}
