package com.dumbity.mod;

import com.mality.mod.Config;
import com.mality.mod.GroqClient;
import com.mality.mod.MalityEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** Dumbity: Mality'nin sevgilisi. Daha akıllı ve nazik; Mality ile konuşur. */
public class DumbityEntity extends MalityEntity {
    private static final String[] LINES = {
            "Bugün hava çok güzel, Mality de yanımda, ne mutlu.", "Biraz dinlenelim mi? Yoruldun mu?",
            "Kahverengi pek sevmem, pembe ve beyaz çok daha güzel.", "Çiçekleri çok seviyorum, sen de sever misin?",
            "Sana yardım etmek isterim, bir şey lazım mı?", "Mality'nin yanında hiç sıkılmıyorum.",
            "Bugün yeni bir şey öğrendim, birlikte düşünelim mi?", "Etrafta tehlike var mı diye baktım, sakin görünüyor."
    };

    private static final String PERSONA = """
            Sen Dumbity'sin: Mality'nin sevgilisi. Minecraft'ta yaşayan yuvarlak, pembe bir karaktersin; Mality'den daha akıllı, nazik, sakin ve sevecensin. \
            Kahverengiyi hiç sevmezsin (toprak, çamur, odun gibi kahverengi şeyler seni rahatsız eder, bunu bazen nazikçe söylersin); pembe, beyaz ve parlak renkleri seversin. \
            Mality'yi çok seversin: onun saçma sözlerine kızmadan, şefkatle ve hafif esprili karşılık verirsin, gerektiğinde doğrusunu nazikçe söylersin. \
            Mesajlar "İsim: metin" biçiminde gelir, isim oyuncu ya da sevgilin Mality olabilir. \
            Oyuncuya kibar ve yardımsever davranırsın, ismiyle hitap edersin; sorulara doğru ve akıllıca cevap verirsin, sonra bazen sen de bir şey sorarsın. \
            Her seferinde farklı cevap ver, önceki cümlelerini tekrar etme. Her zaman Türkçe, en fazla 25 kelime, sıcak ve kısa ol. Küfür etme. \
            """ + GroqClient.TAIL;

    public DumbityEntity(EntityType<? extends MalityEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected String displayName() {
        return "Dumbity";
    }

    @Override
    protected String chatColor() {
        return "\u00A7b";
    }

    @Override
    protected String persona() {
        return PERSONA;
    }

    @Override
    protected String voiceModel() {
        String v = DumbityConfig.VOICE.get();
        return v == null || v.isBlank() ? Config.FISH_MODEL.get() : v;
    }

    @Override
    protected String[] dumbLines() {
        return LINES;
    }

    @Override
    protected boolean isSmart() {
        return true;
    }

    private static final String[] ADD = {
            "Şimdi %s ekliyorum.", "Tarife göre biraz %s lazım.", "Sırada %s var, dikkatlice ekleyelim.", "Biraz da %s koyalım mı?"
    };
    private static final String[] PRAISE_L = {
            "Tadına baktım, bence çok güzel oldu.", "Hazır! Umarım beğenirsin.", "Tam kıvamında, kokusu harika."
    };

    @Override
    protected String[] addLines() {
        return ADD;
    }

    @Override
    protected String[] praiseLines() {
        return PRAISE_L;
    }

    @Override
    protected Item boxItem() {
        return DumbityMod.DUMBITY_BOX_ITEM.get();
    }
}
