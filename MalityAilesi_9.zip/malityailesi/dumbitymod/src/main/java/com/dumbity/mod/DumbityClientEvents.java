package com.dumbity.mod;

import com.mality.mod.ClientMic;
import com.mality.mod.MalityRenderer;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = DumbityMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class DumbityClientEvents {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(DumbityMod.DUMBITY.get(),
                ctx -> new MalityRenderer(ctx, DumbityMod.MODID, "dumbity"));
    }

    /** N tuşu: Dumbity ile konuş (D tuşu zaten "sağa yürü"). */
    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        KeyMapping key = new KeyMapping("key.dumbitymod.talk", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_N, "key.categories.dumbitymod");
        event.register(key);
        ClientMic.addTalker("dumbity", key);
    }
}
