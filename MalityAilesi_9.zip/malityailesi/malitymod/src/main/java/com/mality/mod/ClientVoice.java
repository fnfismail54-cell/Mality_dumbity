package com.mality.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** İstemcide WAV'ı OpenAL ile 3D (Mality'nin konumundan) çalar. Sadece istemci. */
@OnlyIn(Dist.CLIENT)
public final class ClientVoice {
    private static final List<int[]> ACTIVE = new ArrayList<>(); // {source, buffer}

    private ClientVoice() {}

    private record Wav(int channels, int sampleRate, byte[] pcm) {}

    private static Wav parse(byte[] b) {
        if (b.length < 44 || b[0] != 'R' || b[1] != 'I' || b[2] != 'F' || b[3] != 'F') return null;
        ByteBuffer bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);
        int pos = 12;
        int channels = 1;
        int rate = 22050;
        int bits = 16;
        while (pos + 8 <= b.length) {
            String id = new String(b, pos, 4);
            long size = bb.getInt(pos + 4) & 0xFFFFFFFFL;
            int body = pos + 8;
            if (id.equals("fmt ")) {
                channels = bb.getShort(body + 2);
                rate = bb.getInt(body + 4);
                bits = bb.getShort(body + 14);
            } else if (id.equals("data")) {
                long remaining = b.length - body;
                int len = (int) ((size == 0 || size > remaining) ? remaining : size);
                if (bits != 16) return null;
                byte[] pcm = new byte[len - (len % 2)];
                System.arraycopy(b, body, pcm, 0, pcm.length);
                return new Wav(channels, rate, pcm);
            }
            pos = body + (int) size + (int) (size % 2);
        }
        return null;
    }

    private static long lastReport;

    private static void check(String what) {
        int err = AL10.alGetError();
        if (err != AL10.AL_NO_ERROR) throw new IllegalStateException(what + " OpenAL hata kodu " + err);
    }

    private static void report(String msg) {
        long now = System.currentTimeMillis();
        if (now - lastReport < 20_000) return;
        lastReport = now;
        try {
            Minecraft.getInstance().gui.getChat().addMessage(Component.literal("\u00A7c[Mality ses hatası] \u00A77" + msg));
        } catch (Throwable ignored) {
            // sohbet yoksa sadece log
        }
    }

    public static void play(int entityId, byte[] wavBytes) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            int buffer = 0;
            int source = 0;
            try {
                Wav w = parse(wavBytes);
                if (w == null || w.pcm().length == 0) throw new IllegalStateException("gelen ses WAV olarak okunamadı");
                Entity e = mc.level == null || entityId < 0 ? null : mc.level.getEntity(entityId);

                AL10.alGetError(); // eski hatayı temizle
                ByteBuffer data = BufferUtils.createByteBuffer(w.pcm().length);
                data.put(w.pcm()).flip();
                buffer = AL10.alGenBuffers();
                check("alGenBuffers");
                AL10.alBufferData(buffer, w.channels() == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16,
                        data, w.sampleRate());
                check("alBufferData");
                source = AL10.alGenSources();
                check("alGenSources");
                AL10.alSourcei(source, AL10.AL_BUFFER, buffer);
                float vol = mc.options.getSoundSourceVolume(SoundSource.MASTER)
                        * mc.options.getSoundSourceVolume(SoundSource.VOICE);
                AL10.alSourcef(source, AL10.AL_GAIN, Math.min(1.0F, vol));
                if (e != null && w.channels() == 1) {
                    AL10.alSource3f(source, AL10.AL_POSITION, (float) e.getX(), (float) e.getEyeY(), (float) e.getZ());
                    AL10.alSourcef(source, AL10.AL_REFERENCE_DISTANCE, 8.0F);
                    AL10.alSourcef(source, AL10.AL_MAX_DISTANCE, 48.0F);
                    AL10.alSourcef(source, AL10.AL_ROLLOFF_FACTOR, 1.0F);
                } else {
                    // konumsuz: doğrudan kulağında çalar
                    AL10.alSourcei(source, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
                    AL10.alSource3f(source, AL10.AL_POSITION, 0.0F, 0.0F, 0.0F);
                }
                check("alSource");
                AL10.alSourcePlay(source);
                check("alSourcePlay");
                ACTIVE.add(new int[]{source, buffer});
            } catch (Throwable t) {
                try {
                    if (source != 0) AL10.alDeleteSources(source);
                    if (buffer != 0) AL10.alDeleteBuffers(buffer);
                } catch (Throwable ignored) {
                    // temizlik başarısız
                }
                MalityMod.LOGGER.warn("[Mality] ses çalınamadı: {}", String.valueOf(t));
                report(String.valueOf(t.getMessage() == null ? t.toString() : t.getMessage()));
            }
        });
    }

    /** Biten sesleri temizle (her client tick). */
    public static void tick() {
        if (ACTIVE.isEmpty()) return;
        try {
            Iterator<int[]> it = ACTIVE.iterator();
            while (it.hasNext()) {
                int[] a = it.next();
                int st = AL10.alGetSourcei(a[0], AL10.AL_SOURCE_STATE);
                if (st != AL10.AL_PLAYING && st != AL10.AL_PAUSED) {
                    AL10.alDeleteSources(a[0]);
                    AL10.alDeleteBuffers(a[1]);
                    it.remove();
                }
            }
        } catch (Throwable ignored) {
            ACTIVE.clear();
        }
    }
}
