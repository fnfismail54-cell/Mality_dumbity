package com.mality.mod;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

/** Aile üyeleri (ör. Dumbity modu) buraya kendini kaydeder; Mality modu onları tanır ama gerektirmez. */
public final class Family {
    /** kind: küçük harf isim ("dumbity"); type: kutudan çıkacak varlık; boxTexture: kutunun dokusu. */
    public record Member(String kind, Supplier<EntityType<? extends MalityEntity>> type, ResourceLocation boxTexture) {}

    private static final Map<String, Member> MEMBERS = new ConcurrentHashMap<>();

    private Family() {}

    public static void register(Member m) {
        MEMBERS.put(m.kind(), m);
    }

    public static Member get(String kind) {
        return kind == null ? null : MEMBERS.get(kind);
    }

    public static Set<String> names() {
        return MEMBERS.keySet();
    }
}
