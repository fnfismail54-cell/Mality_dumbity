package com.mality.mod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Küre ve kutu çizim yardımcıları (istemci). */
public final class SphereRender {
    private SphereRender() {}

    private static void v(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float z,
                          float u, float vv, float nx, float ny, float nz, int light) {
        vc.vertex(m, x, y, z).color(255, 255, 255, 255).uv(u, vv)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, nx, ny, nz).endVertex();
    }

    /**
     * Küre çizer. Ön yarım küre (z>0) atlas hücresinin (u0,v0,du,dv) düz izdüşümüyle kaplanır,
     * arka yarı (bodyU, bodyV) tek renk pikseline eşlenir. Yüz +Z'dedir.
     */
    public static void sphere(VertexConsumer vc, PoseStack ps, float r, float u0, float v0, float du, float dv,
                              float bodyU, float bodyV, int light) {
        PoseStack.Pose pose = ps.last();
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        int lat = 12, lon = 20;
        for (int i = 0; i < lat; i++) {
            float t0 = (float) Math.PI * i / lat, t1 = (float) Math.PI * (i + 1) / lat;
            for (int j = 0; j < lon; j++) {
                float p0 = (float) (2 * Math.PI) * j / lon, p1 = (float) (2 * Math.PI) * (j + 1) / lon;
                float[][] pts = {pt(t0, p0), pt(t0, p1), pt(t1, p1), pt(t1, p0)};
                for (float[] q : pts) {
                    float x = q[0], y = q[1], z = q[2];
                    float u, vv;
                    if (z > 0) {
                        u = u0 + (x * 0.5F + 0.5F) * du;
                        vv = v0 + (-y * 0.5F + 0.5F) * dv;
                    } else {
                        u = bodyU;
                        vv = bodyV;
                    }
                    v(vc, m, n, x * r, y * r, z * r, u, vv, x, y, z, light);
                }
            }
        }
    }

    private static float[] pt(float theta, float phi) {
        // y yukarı, z ileri
        float y = (float) Math.cos(theta);
        float s = (float) Math.sin(theta);
        return new float[]{s * (float) Math.sin(phi), y, s * (float) Math.cos(phi)};
    }

    /** Tüm yüzlerde tam doku olan kutu. */
    public static void box(VertexConsumer vc, PoseStack ps, float x0, float y0, float z0, float x1, float y1, float z1, int light) {
        PoseStack.Pose pose = ps.last();
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        // +Z
        quad(vc, m, n, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0, 0, 1, light);
        // -Z
        quad(vc, m, n, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, 0, 0, -1, light);
        // +X
        quad(vc, m, n, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, 1, 0, 0, light);
        // -X
        quad(vc, m, n, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, -1, 0, 0, light);
        // +Y
        quad(vc, m, n, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, 0, 1, 0, light);
        // -Y
        quad(vc, m, n, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0, -1, 0, light);
    }

    private static void quad(VertexConsumer vc, Matrix4f m, Matrix3f n,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float nx, float ny, float nz, int light) {
        v(vc, m, n, ax, ay, az, 0, 1, nx, ny, nz, light);
        v(vc, m, n, bx, by, bz, 1, 1, nx, ny, nz, light);
        v(vc, m, n, cx, cy, cz, 1, 0, nx, ny, nz, light);
        v(vc, m, n, dx, dy, dz, 0, 0, nx, ny, nz, light);
    }
}
