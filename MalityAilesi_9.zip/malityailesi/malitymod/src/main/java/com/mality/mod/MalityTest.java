package com.mality.mod;

import com.google.gson.JsonObject;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;

/** /malitytest : Groq, Fish Audio ve ses çalmayı tek tek dener, sonucu sohbete yazar. */
public final class MalityTest {
    private MalityTest() {}

    public static String rootMessage(Throwable t) {
        if (t == null) return "bilinmeyen hata";
        Throwable c = t;
        while (c.getCause() != null && c.getCause() != c) c = c.getCause();
        String m = c.getMessage();
        return m == null || m.isBlank() ? c.getClass().getSimpleName() : m;
    }

    private static String mask(String k) {
        if (k == null || k.isBlank()) return "YOK";
        return k.substring(0, Math.min(4, k.length())) + "... (" + k.length() + " karakter)";
    }

    private static void tell(ServerPlayer p, String s) {
        p.sendSystemMessage(Component.literal(s));
    }

    public static void run(ServerPlayer p) {
        MinecraftServer server = p.getServer();
        String gkey = GroqClient.cleanKey(Config.GROQ_API_KEY.get());
        String fkey = FishClient.cleanKey(Config.FISH_API_KEY.get());
        String voice = FishClient.cleanVoiceId(Config.FISH_MODEL.get());

        tell(p, "\u00A7e[Mality testi] Groq key: " + mask(gkey) + " | model: " + GroqClient.fixModel(Config.GROQ_MODEL.get()));
        tell(p, "\u00A7e[Mality testi] Fish key: " + mask(fkey) + " | ses modeli: "
                + (voice.isEmpty() ? "YOK (varsayılan ses)" : voice) + " | motor: " + Config.FISH_ENGINE.get());

        if (gkey.isEmpty()) {
            tell(p, "\u00A7c[Groq] Key boş. Mods > Mality > Config'e yaz.");
        } else {
            GroqClient.ask(gkey, Config.GROQ_MODEL.get(), List.<JsonObject>of(), p.getGameProfile().getName(),
                            "Merhaba, beni duyuyor musun?")
                    .whenComplete((r, e) -> server.execute(() -> {
                        if (e != null || r == null) tell(p, "\u00A7c[Groq] HATA: " + rootMessage(e));
                        else tell(p, "\u00A7a[Groq] ÇALIŞIYOR. Cevap: " + r.say());
                    }));
        }

        if (fkey.isEmpty()) {
            tell(p, "\u00A7c[Fish Audio] Key boş, Mality sessiz konuşur.");
        } else {
            FishClient.tts(fkey, Config.FISH_MODEL.get(), Config.FISH_ENGINE.get(), "Merhaba, ben Mality!")
                    .whenComplete((d, e) -> server.execute(() -> {
                        if (e != null || d == null) {
                            tell(p, "\u00A7c[Fish Audio] HATA: " + rootMessage(e));
                        } else {
                            tell(p, "\u00A7a[Fish Audio] ÇALIŞIYOR (" + d.length + " bayt ses geldi). Şimdi çalınıyor...");
                            MalityNet.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new VoicePacket(-1, d));
                        }
                    }));
        }

        tell(p, "\u00A7e[Ses testi] Şimdi bir BİP sesi çalıyorum. Duymazsan sorun Fish'te değil, oyunun ses çalma kısmında.");
        MalityNet.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new VoicePacket(-1, beep()));
    }

    private static byte[] beep() {
        int rate = 24000;
        int n = rate / 2;
        ByteBuffer b = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes()).putInt(36 + n * 2).put("WAVE".getBytes());
        b.put("fmt ".getBytes()).putInt(16).putShort((short) 1).putShort((short) 1)
                .putInt(rate).putInt(rate * 2).putShort((short) 2).putShort((short) 16);
        b.put("data".getBytes()).putInt(n * 2);
        for (int i = 0; i < n; i++) {
            double env = Math.min(1.0, Math.min(i, n - i) / (rate * 0.05));
            b.putShort((short) (Math.sin(2 * Math.PI * 660.0 * i / rate) * 12000 * env));
        }
        return b.array();
    }
}
