package com.mality.mod;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.List;
import java.util.function.Supplier;

/** İstemciden sunucuya: sesle söylenen metin, sohbette görünmeden hedefe ("mality", "dumbity"...) gider. */
public record MicPacket(String text, String target) {
    public static void encode(MicPacket p, FriendlyByteBuf b) {
        b.writeUtf(p.text(), 256);
        b.writeUtf(p.target(), 32);
    }

    public static MicPacket decode(FriendlyByteBuf b) {
        return new MicPacket(b.readUtf(256), b.readUtf(32));
    }

    public static void handle(MicPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;
            String raw = p.text().trim();
            if (raw.isEmpty()) return;
            List<MalityEntity> list = sp.serverLevel().getEntitiesOfClass(MalityEntity.class,
                    sp.getBoundingBox().inflate(Config.CHAT_RANGE.get()));
            String folded = MalityEntity.fold(raw);
            List<MalityEntity> pool = list.stream()
                    .filter(e -> MalityEntity.fold(e.displayName()).equals(p.target())).toList();
            MalityEntity m = MalityEntity.pickListener(pool.isEmpty() ? list : pool, sp, folded);
            if (m != null) m.hear(sp, raw, folded);
        });
        ctx.get().setPacketHandled(true);
    }
}
