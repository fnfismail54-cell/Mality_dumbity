package com.mality.mod;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.BufferUtils;
import org.lwjgl.openal.ALC10;
import org.lwjgl.openal.ALC11;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Bas-konuş: M tuşuna basılı tut, konuş. Sessizlik olunca (ya da tuşu bırakınca) kayıt Groq Whisper ile
 * yazıya çevrilir ve sohbete gönderilir. Sadece istemci.
 */
@OnlyIn(Dist.CLIENT)
public final class ClientMic {
    /** Konuşma tuşu + hedef ("mality", "dumbity"...). Diğer modlar addTalker ile kendi tuşunu ekler. */
    public record Talker(String target, KeyMapping key) {}

    private static final java.util.List<Talker> TALKERS = new java.util.concurrent.CopyOnWriteArrayList<>();
    private static Talker current;

    public static void addTalker(String target, KeyMapping key) {
        TALKERS.add(new Talker(target, key));
    }

    private static final int RATE = 16000;
    private static final int SPEECH_PEAK = 2200;      // bu genliğin üstü = konuşma
    private static final int SILENCE_TICKS = 26;      // ~1.3 sn sessizlik = bitti
    private static final int NO_SPEECH_TICKS = 20 * 8; // 8 sn hiç konuşulmazsa iptal
    private static final int MAX_TICKS = 20 * 25;     // en fazla 25 sn

    private static long device;
    private static boolean recording;
    private static boolean spoke;
    private static boolean needRelease;
    private static boolean busy;
    private static int silentTicks;
    private static int totalTicks;
    private static final ByteArrayOutputStream PCM = new ByteArrayOutputStream();

    private ClientMic() {}

    private static void err(String msg) {
        try {
            Minecraft.getInstance().gui.getChat().addMessage(Component.literal("§c[Mality mikrofon] §7" + msg));
        } catch (Throwable ignored) {
            // sohbet yok
        }
    }

    private static void status(String msg) {
        try {
            Minecraft.getInstance().gui.setOverlayMessage(Component.literal(msg), false);
        } catch (Throwable ignored) {
            // yok say
        }
    }

    public static void tick() {
        if (TALKERS.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            if (recording) abort();
            return;
        }
        Talker pressed = null;
        for (Talker t : TALKERS) {
            if (t.key().isDown()) {
                pressed = t;
                break;
            }
        }
        if (pressed == null) needRelease = false;

        if (!recording) {
            if (pressed != null && !needRelease && !busy && mc.screen == null) {
                current = pressed;
                start();
            }
            return;
        }
        boolean down = current != null && current.key().isDown();

        drain();
        totalTicks++;

        if (!down) {
            finish();
        } else if (spoke && silentTicks >= SILENCE_TICKS) {
            needRelease = true; // tuş hâlâ basılıysa hemen yeniden başlamasın
            finish();
        } else if (!spoke && totalTicks > NO_SPEECH_TICKS) {
            needRelease = true;
            abort();
        } else if (totalTicks > MAX_TICKS) {
            needRelease = true;
            finish();
        }
    }

    private static void start() {
        try {
            device = ALC11.alcCaptureOpenDevice((CharSequence) null, RATE, org.lwjgl.openal.AL10.AL_FORMAT_MONO16, RATE * 2);
            if (device == 0L) {
                err("Mikrofon açılamadı. Android'de Zalith'e mikrofon izni ver (Ayarlar > Uygulamalar > Zalith > İzinler > Mikrofon).");
                needRelease = true;
                return;
            }
            ALC11.alcCaptureStart(device);
            PCM.reset();
            recording = true;
            spoke = false;
            silentTicks = 0;
            totalTicks = 0;
        } catch (Throwable t) {
            device = 0L;
            err("Mikrofon başlatılamadı: " + t);
            needRelease = true;
        }
    }

    private static void drain() {
        try {
            int avail = ALC10.alcGetInteger(device, ALC11.ALC_CAPTURE_SAMPLES);
            if (avail <= 0) {
                silentTicks++;
                return;
            }
            ByteBuffer buf = BufferUtils.createByteBuffer(avail * 2);
            ALC11.alcCaptureSamples(device, buf, avail);
            buf.order(ByteOrder.LITTLE_ENDIAN);
            int peak = 0;
            byte[] bytes = new byte[avail * 2];
            buf.get(bytes);
            for (int i = 0; i + 1 < bytes.length; i += 2) {
                int s = (short) ((bytes[i] & 0xFF) | (bytes[i + 1] << 8));
                peak = Math.max(peak, Math.abs(s));
            }
            PCM.write(bytes, 0, bytes.length);
            if (peak >= SPEECH_PEAK) {
                spoke = true;
                silentTicks = 0;
            } else {
                silentTicks++;
            }
        } catch (Throwable t) {
            err("Mikrofon okunamadı: " + t);
            abort();
        }
    }

    private static void closeDevice() {
        try {
            if (device != 0L) {
                ALC11.alcCaptureStop(device);
                ALC11.alcCaptureCloseDevice(device);
            }
        } catch (Throwable ignored) {
            // kapatma hatası
        }
        device = 0L;
        recording = false;
    }

    private static void abort() {
        closeDevice();
        PCM.reset();
    }

    private static void finish() {
        boolean hadSpeech = spoke;
        closeDevice();
        byte[] pcm = PCM.toByteArray();
        PCM.reset();
        if (!hadSpeech || pcm.length < RATE) return; // 0.5 sn'den kısa: yok say

        String key = GroqClient.cleanKey(Config.GROQ_API_KEY.get());
        if (key.isEmpty()) {
            err("Groq API anahtarı yok. Mods > Mality > Config menüsünden gir.");
            return;
        }
        busy = true;
        final String tgt = current == null ? "mality" : current.target();
        GroqClient.transcribe(key, wav(pcm)).whenComplete((text, e) -> Minecraft.getInstance().execute(() -> {
            busy = false;
            if (e != null) {
                err(MalityTest.rootMessage(e));
                return;
            }
            sendToChat(text, tgt);
        }));
    }

    private static void sendToChat(String text, String tgt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || text == null) return;
        String t = text.trim().replaceAll("^/+", "");
        if (t.length() < 2) return;
        MalityNet.CHANNEL.sendToServer(new MicPacket(t, tgt)); // sohbette görünmez, direkt Mality'ye gider
    }

    private static byte[] wav(byte[] pcm) {
        ByteBuffer b = ByteBuffer.allocate(44 + pcm.length).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes()).putInt(36 + pcm.length).put("WAVE".getBytes());
        b.put("fmt ".getBytes()).putInt(16).putShort((short) 1).putShort((short) 1)
                .putInt(RATE).putInt(RATE * 2).putShort((short) 2).putShort((short) 16);
        b.put("data".getBytes()).putInt(pcm.length).put(pcm);
        return b.array();
    }
}
