MALITY AILESI  -  Minecraft Java 1.20.1  -  Forge 47.x  -  Java 17
==============================================================

ICINDEKILER (IKI AYRI MOD, TEK KLASOR)
  malitymod/    Mality Modu   -> build/libs/malitymod-1.0.0.jar
  dumbitymod/   Dumbity Modu  -> build/libs/dumbitymod-1.0.0.jar   (malitymod GEREKTIRIR)
mods klasorune: sadece Mality istersen malitymod.jar; Dumbity de istersen IKISINI birden at.
Dumbity tek basina calismaz (Mality modunun uzerine kuruludur). Mality tek basina calisir.

GITHUB ILE DERLEME (bilgisayarsiz)
Deponun kokune bu zip'i (acmadan) ve .github/workflows/build.yml dosyasini koy. Workflow zip'i acip
iki modu derler, Releases'e iki jar koyar.

TUSLAR / KOMUTLAR
- M basili tut: Mality ile konus.   N basili tut: Dumbity ile konus (D yurume "saga" ile cakisir).
- /malitykutu (mavi kutu), /dumbitykutu (pembe kutu), /dumbityses <fish ses id>, /malitytest, /setmalityyatak
- Egilerek (shift) sag tik: Mality/Dumbity kutu olarak envantere gelir. Normal sag tik: sevinir.
- Telefon: Dumbity, Mality uzaktayken (30+ blok) arada onu arar, "[Dumbity telefonda]" konusurlar.
- Yeni yuzler: mality_excited / mality_surprised (malitymod), dumbity_excited / dumbity_surprised (dumbitymod).
  Yuz dosyalari: <mod>/src/main/resources/assets/<modid>/textures/entity/  (adlari degistirme, ustune yaz)
- Ayarlar (Groq/Fish anahtarlari): config/malitymod-common.toml ; Dumbity sesi: config/dumbitymod-common.toml

--- ASAGISI Mality modunun eski aciklamasi ---

MALITY MOD  -  Minecraft Java 1.20.1  -  Forge 47.x  -  Java 17
==============================================================

KURULUM / DERLEME (en kolay yol)
1) https://files.minecraftforge.net adresinden 1.20.1 icin "MDK" indir (47.3.0 veya yakini) ve ac.
2) Bu zip'teki "src" klasorunu MDK'nin icindeki "src" klasorunun ustune kopyala (mevcut Example mod
   dosyalarini sil: src/main/java/com/example..., eski mods.toml).
3) MDK'deki build.gradle ve gradle.properties icindeki mod id'yi "malitymod", paket/group'u
   "com.mality.mod" yap. (Alternatif: bu zip'teki build.gradle'i ve settings.gradle'i kullan,
   gradle wrapper'i MDK'den kopyala: gradlew, gradlew.bat, gradle/ klasoru.)
4) JDK 17 kurulu olsun. Terminalde:   gradlew build
5) Jar:  build/libs/malitymod-1.0.0.jar  ->  .minecraft/mods klasorune at.
   (Forge 1.20.1 kurulu olmali.)

OYUN ICI (v2)
- Yaratici envanteri > "Mality" sekmesi: Malitynin Mavi Kutusu, Mality Canlandirma Yumurtasi,
  Malitynin Super Keki.
- Mavi kutuyu yere koy, SAG TIK: havaya kalkar, ses cikar, Mality duser ("tip"), sacma seyler soyler.
- Ayarlar: Mods > Mality > Config: Groq API key + model, Fish Audio API key + Fish Audio ses model ID
  (Fish Audio sitesindeki voice model ID), "mality de" kutusu.
  Fish Audio key bos ise Mality sessiz konusur (sadece yazi). Anahtarlar config/malitymod-common.toml
  icinde duz yazi saklanir, paylasma!
- Komutlar: "yemek yap" (asci sapkasi, tezgah, malzemeler, super kek), "yemek ye", "toprak ver",
  "yardim et", "ev yap" (kotu ev; "kotu ev yap" derseniz guzel yapar), "kopek kulubesi yap" (malikane),
  "kopru yap" (yukari; "kotu kopru" duz yapar), "uyu", "takip et", "dur/bekle".
- Sohbete /setmalityyatak yaz: en yakin Mality'nin yatagi bulundugun yer olur. "uyu" deyince ya da
  gece olunca yuvarlanarak oraya gider ve uyur.
- Super kek: bulanti + rastgele ucak / tavsan (yuksek ziplama) / osuruk. Zehirliyse kisa zehir (olmez).

YUZLER (HER YUZ AYRI DOSYA)
assets/malitymod/textures/entity/ icinde 7 ayri dosya (her biri kare, ornegin 64x64 ya da 128x128):
  mality_happy.png        normal mutlu
  mality_happy_talk.png   mutlu konusurken
  mality_bored.png        sikilmis / korkunc
  mality_bored_talk.png   sikilmis konusurken
  mality_sleep.png        uyuyan
  mality_scared.png       korkmus
  mality_fall.png         kutudan duserken
Her resmin ortasina YUVARLAK yuz ciz. Resmin kenarlari / sol ust kosesi top rengi olsun
(topun arka yarisi o kosenin rengini alir). Dosya adlarini degistirme, ustune yaz.

SESLI KONUSMA (v3)
- M tusuna basili tut ve konus. Sessizlik olunca (ya da tusu birakinca) konusman Groq Whisper ile yaziya
  cevrilip sohbette GORUNMEDEN dogrudan Mality'ye gider, Mality cevap verir. Tus: Kontroller > "Mality" kategorisi.
- Android'de Zalith'e mikrofon izni ver (Ayarlar > Uygulamalar > Zalith > Izinler > Mikrofon).

DUMBITY (Mality'nin sevgilisi)
- Pembe kutu (Yaratici envanteri > Mality sekmesi) ya da oyuna ilk giriste yaninda dogan iki kutu: mavi = Mality, pembe = Dumbity.
  /malitykutu yazarsan iki kutu yine yaninda dogar. Kutuya sag tik.
- Konusma: M basili tut = Mality, N basili tut = Dumbity (Kontroller > Mality). Sohbete "dumbity ..." yazarsan da Dumbity duyar.
- Dumbity "yemek yap" duyunca genis kuvars tezgah kurar, Mality'yi de cagirir: o iyi (bazen yanlislikla kotu), Mality kotu yemek yapar.
- Mality'ye "kopek kulubesi yap": kuvarstan, camli, ici dosenmis 2 katli ev.
- Dumbity ses modeli: /dumbityses <fish ses id>

YENI (v8)
- Yeni yuzler (her biri ayri dosya, kendi yuzlerinle ustune yazabilirsin):
    mality_excited.png / dumbity_excited.png     asiri neseli (sevinince, yemek bitince, bulusunca, ev yapinca)
    mality_surprised.png / dumbity_surprised.png saskin (bir seye sasirinca: zombi, elmas, kutudan dusunce, kahverengi)
- Telefon: Dumbity, Mality yanindayken degilse (30+ blok uzakta) ve sen yakindaysan arada Mality'yi arar,
  sohbette "[Dumbity telefonda]" / "[Mality telefonda]" olarak konusurlar, sonra kapatir. Yaklasinca sevinirler.
- Envantere alma: Mality ya da Dumbity'ye egilerek (shift) SAG TIK: kutusu envanterine gelir; kutuyu yere koyup sag tiklayinca yine cikar.
  Normal sag tik: sevinir.
- Mality artik cok seyrek "toprak/elmas/komur" der (3 dk - 5 dk arayla, ihtimalle).
- Dumbity kahverengi (toprak, odun) cok olan yerde nadiren kahverengiyi sevmedigini soyler.
- Dumbity ile konusma tusu N (D tusu yurume "saga" ile cakisir). Kontroller > Mality'den D yapabilirsin ama saga yurur.

SORUN GIDERME
- Oyunda sohbete /malitytest yaz: Groq, Fish Audio ve ses calma ayri ayri denenir, sonuc sohbette cikar.
- Mality'nin Groq/ses hatalari sohbette kirmizi "[Mality hata]" olarak gorunur.

BILGISAYARSIZ DERLEME (GitHub ile)
Depoya (repo) tum dosyalari, .github/workflows/build.yml dahil, yukle. Actions sekmesi >
"Build Mality Mod" > Run workflow. Bitince "malitymod-jar" artifact'ini indir, icinden jar cikar.
